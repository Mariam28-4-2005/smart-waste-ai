
export enum WasteCategory {
    Recycling = 'Recycling',
    Compost = 'Compost',
    Landfill = 'Landfill',
    Hazardous = 'Hazardous',
    Special = 'Special',
    Unknown = 'Unknown'
}

export interface ScanResult {
    itemName: string;
    category: WasteCategory;
    reason: string;
    imageUrl: string;
}

export interface Badge {
    name: string;
    description: string;
    icon: string;
    pointsRequired: number;
}

export interface LeaderboardUser {
    name: string;
    points: number;
    isUser?: boolean;
}

export interface RecyclingCenter {
    name: string;
    address: string;
    hours: string;
    accepts: string[];
}
