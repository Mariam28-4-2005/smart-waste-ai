
import React from 'react';
import { LeafIcon } from './Icons';

export const Header: React.FC = () => {
  return (
    <header className="w-full bg-green-600 text-white p-4 shadow-md flex items-center justify-center">
      <LeafIcon className="h-8 w-8 mr-2" />
      <h1 className="text-2xl font-bold tracking-tight">EcoSort AI</h1>
    </header>
  );
};
