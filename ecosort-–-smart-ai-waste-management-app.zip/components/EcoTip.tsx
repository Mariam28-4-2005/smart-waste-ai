
import React, { useMemo } from 'react';
import { ECO_TIPS } from '../constants';
import { LightBulbIcon } from './Icons';

export const EcoTip: React.FC = () => {
  const tip = useMemo(() => ECO_TIPS[Math.floor(Math.random() * ECO_TIPS.length)], []);

  return (
    <div className="bg-green-100 p-3">
      <div className="flex items-center">
        <LightBulbIcon className="h-6 w-6 text-green-600 mr-3 flex-shrink-0" />
        <div>
          <h4 className="font-bold text-sm text-green-800">Eco Tip!</h4>
          <p className="text-xs text-green-700">{tip}</p>
        </div>
      </div>
    </div>
  );
};
