
import React from 'react';
import type { ScanResult } from '../types';
import { WasteCategory } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface StatsProps {
  scanHistory: ScanResult[];
  ecoPoints: number;
}

const COLORS: { [key in WasteCategory]?: string } = {
    [WasteCategory.Recycling]: '#3b82f6', // blue-500
    [WasteCategory.Compost]: '#16a34a', // green-600
    [WasteCategory.Landfill]: '#6b7280', // gray-500
    [WasteCategory.Hazardous]: '#dc2626', // red-600
    [WasteCategory.Special]: '#f97316', // orange-500
    [WasteCategory.Unknown]: '#facc15', // yellow-400
};

export const Stats: React.FC<StatsProps> = ({ scanHistory, ecoPoints }) => {
  const statsData = React.useMemo(() => {
    const counts = scanHistory.reduce((acc, item) => {
      acc[item.category] = (acc[item.category] || 0) + 1;
      return acc;
    }, {} as { [key in WasteCategory]: number });

    return Object.entries(counts).map(([name, value]) => ({
      name,
      count: value,
    }));
  }, [scanHistory]);

  const co2Saved = React.useMemo(() => {
      const recyclingCount = scanHistory.filter(item => item.category === WasteCategory.Recycling).length;
      const compostCount = scanHistory.filter(item => item.category === WasteCategory.Compost).length;
      // Approximate values: 2.5 kg CO2 saved per kg recycled, 0.5 kg CO2 per kg composted
      // Assuming avg item weight of 0.1 kg
      return (recyclingCount * 0.25 + compostCount * 0.05).toFixed(2);
  }, [scanHistory]);

  return (
    <div className="p-2 space-y-6 animate-fade-in">
      <h1 className="text-3xl font-bold text-gray-800">Your Impact</h1>

      <div className="grid grid-cols-2 gap-4 text-center">
        <div className="bg-green-100 p-4 rounded-lg shadow">
          <p className="text-3xl font-bold text-green-700">{ecoPoints}</p>
          <p className="text-sm font-medium text-green-600">Eco-Points</p>
        </div>
        <div className="bg-blue-100 p-4 rounded-lg shadow">
          <p className="text-3xl font-bold text-blue-700">{scanHistory.length}</p>
          <p className="text-sm font-medium text-blue-600">Items Scanned</p>
        </div>
      </div>
      
      <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-3xl font-bold text-gray-700 text-center">{co2Saved} kg</p>
          <p className="text-sm font-medium text-gray-600 text-center">Estimated CO₂ Saved</p>
      </div>

      <div className="bg-white p-4 rounded-lg shadow">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Sorting Breakdown</h2>
        {scanHistory.length > 0 ? (
          <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer>
              <BarChart data={statsData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} />
                <Tooltip cursor={{fill: 'rgba(230, 230, 230, 0.5)'}} />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                    {statsData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[entry.name as WasteCategory] || '#8884d8'} />
                    ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="text-center py-10">
            <p className="text-gray-500">Scan some items to see your stats!</p>
          </div>
        )}
      </div>
    </div>
  );
};
