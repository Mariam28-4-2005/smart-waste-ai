
import React from 'react';
import type { Badge, LeaderboardUser } from '../types';
import { TrophyIcon } from './Icons';

interface RewardsProps {
  unlockedBadges: Badge[];
  leaderboardData: LeaderboardUser[];
}

export const Rewards: React.FC<RewardsProps> = ({ unlockedBadges, leaderboardData }) => {
  return (
    <div className="p-2 space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold text-gray-800">Your Rewards</h1>
        <p className="text-gray-600">Keep up the great work for a greener planet!</p>
      </div>

      {/* Badges Section */}
      <div className="bg-white p-4 rounded-lg shadow">
        <h2 className="text-xl font-semibold text-gray-700 mb-4 flex items-center">
          <TrophyIcon className="h-6 w-6 text-yellow-500 mr-2" />
          Unlocked Badges
        </h2>
        {unlockedBadges.length > 0 ? (
          <div className="grid grid-cols-3 gap-4 text-center">
            {unlockedBadges.map((badge) => (
              <div key={badge.name} className="flex flex-col items-center p-2">
                <i className={`${badge.icon} text-4xl text-yellow-500`}></i>
                <p className="mt-2 text-sm font-semibold text-gray-700">{badge.name}</p>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-gray-500">Start scanning to earn badges!</p>
          </div>
        )}
      </div>

      {/* Leaderboard Section */}
      <div className="bg-white p-4 rounded-lg shadow">
        <h2 className="text-xl font-semibold text-gray-700 mb-4">Community Leaderboard</h2>
        <ul className="space-y-3">
          {leaderboardData.map((user, index) => (
            <li
              key={index}
              className={`flex items-center justify-between p-3 rounded-lg ${
                user.isUser ? 'bg-green-100 border-2 border-green-500' : 'bg-gray-50'
              }`}
            >
              <div className="flex items-center">
                <span className="font-bold text-gray-600 w-8">{index + 1}.</span>
                <span className={`font-semibold ${user.isUser ? 'text-green-800' : 'text-gray-800'}`}>{user.name}</span>
              </div>
              <span className={`font-bold text-lg ${user.isUser ? 'text-green-700' : 'text-gray-600'}`}>
                {user.points}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
