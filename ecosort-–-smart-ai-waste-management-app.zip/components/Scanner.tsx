
import React, { useState, useRef, useCallback } from 'react';
import { classifyWaste } from '../services/geminiService';
import type { ScanResult } from '../types';
import { WasteCategory } from '../types';
import { CameraIcon, PaperPlaneIcon, ArrowPathIcon, RecyclingBinIcon, CompostIcon, TrashCanIcon, BiohazardIcon, QuestionMarkIcon } from './Icons';

interface ScannerProps {
  onScanComplete: (result: ScanResult) => void;
  latestResult: ScanResult | null;
}

const getCategoryStyles = (category: WasteCategory) => {
    switch (category) {
        case WasteCategory.Recycling:
            return {
                bgColor: 'bg-blue-100',
                textColor: 'text-blue-800',
                borderColor: 'border-blue-500',
                icon: <RecyclingBinIcon className="h-8 w-8 text-blue-600" />
            };
        case WasteCategory.Compost:
            return {
                bgColor: 'bg-green-100',
                textColor: 'text-green-800',
                borderColor: 'border-green-500',
                icon: <CompostIcon className="h-8 w-8 text-green-600" />
            };
        case WasteCategory.Landfill:
            return {
                bgColor: 'bg-gray-100',
                textColor: 'text-gray-800',
                borderColor: 'border-gray-500',
                icon: <TrashCanIcon className="h-8 w-8 text-gray-600" />
            };
        case WasteCategory.Hazardous:
            return {
                bgColor: 'bg-red-100',
                textColor: 'text-red-800',
                borderColor: 'border-red-500',
                icon: <BiohazardIcon className="h-8 w-8 text-red-600" />
            };
        default:
            return {
                bgColor: 'bg-yellow-100',
                textColor: 'text-yellow-800',
                borderColor: 'border-yellow-500',
                icon: <QuestionMarkIcon className="h-8 w-8 text-yellow-600" />
            };
    }
};

const ResultCard: React.FC<{ result: ScanResult }> = ({ result }) => {
  const { bgColor, textColor, borderColor, icon } = getCategoryStyles(result.category);

  return (
    <div className="w-full mx-auto bg-white rounded-xl shadow-md overflow-hidden animate-fade-in">
        <div className={`p-6 border-l-8 ${borderColor} ${bgColor}`}>
            <div className="flex items-center space-x-4">
                <div className="flex-shrink-0">{icon}</div>
                <div>
                    <div className={`text-xl font-bold ${textColor}`}>{result.category}</div>
                    <p className={`mt-1 text-md font-semibold ${textColor}`}>{result.itemName}</p>
                </div>
            </div>
            <p className={`mt-4 text-sm ${textColor}`}>{result.reason}</p>
        </div>
        <img className="h-48 w-full object-cover" src={result.imageUrl} alt={result.itemName} />
    </div>
  );
};


export const Scanner: React.FC<ScannerProps> = ({ onScanComplete, latestResult }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
      setError(null);
    }
  };

  const handleScan = async () => {
    if (!selectedFile) {
      setError('Please select an image first.');
      return;
    }
    setIsLoading(true);
    setError(null);

    try {
      const result = await classifyWaste(selectedFile);
      onScanComplete({...result, imageUrl: previewUrl!});
    } catch (err) {
      console.error(err);
      setError('Could not classify the item. Please try again.');
    } finally {
      setIsLoading(false);
      setSelectedFile(null);
      setPreviewUrl(null);
    }
  };

  const handleTriggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const showInitialState = !previewUrl && !isLoading && !latestResult;

  return (
    <div className="flex flex-col items-center justify-center h-full text-center">
      {isLoading && (
        <div className="flex flex-col items-center justify-center space-y-4">
          <ArrowPathIcon className="h-16 w-16 text-green-500 animate-spin" />
          <p className="text-lg font-semibold text-gray-700">Analyzing item...</p>
          <p className="text-sm text-gray-500">Our AI is working its magic!</p>
        </div>
      )}

      {error && !isLoading && (
        <div className="p-4 bg-red-100 text-red-700 rounded-lg">
          <p>{error}</p>
        </div>
      )}
      
      {latestResult && !isLoading && !previewUrl && (
          <div className="w-full space-y-4">
              <h2 className="text-2xl font-bold text-gray-800">Last Scan Result</h2>
              <ResultCard result={latestResult} />
              <button
                  onClick={handleTriggerFileInput}
                  className="w-full mt-4 bg-green-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-700 transition duration-300 flex items-center justify-center text-lg"
              >
                  <CameraIcon className="h-6 w-6 mr-2" />
                  Scan Another Item
              </button>
          </div>
      )}

      {previewUrl && !isLoading && (
        <div className="w-full flex flex-col items-center space-y-4">
          <img src={previewUrl} alt="Preview" className="w-full max-h-64 object-contain rounded-lg shadow-md" />
          <div className="flex w-full space-x-2">
            <button
              onClick={handleTriggerFileInput}
              className="flex-1 bg-gray-200 text-gray-700 font-bold py-3 px-4 rounded-lg hover:bg-gray-300 transition duration-300 flex items-center justify-center"
            >
              <ArrowPathIcon className="h-5 w-5 mr-2" />
              Change
            </button>
            <button
              onClick={handleScan}
              className="flex-1 bg-green-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-green-700 transition duration-300 flex items-center justify-center"
            >
              Classify
              <PaperPlaneIcon className="h-5 w-5 ml-2" />
            </button>
          </div>
        </div>
      )}

      {showInitialState && (
        <div
          onClick={handleTriggerFileInput}
          className="w-full h-64 border-4 border-dashed border-gray-300 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-green-500 hover:bg-gray-50 transition duration-300"
        >
          <CameraIcon className="h-16 w-16 text-gray-400 mb-4" />
          <h2 className="text-xl font-semibold text-gray-700">Tap to Scan Waste</h2>
          <p className="text-gray-500 mt-2">Let's sort it out!</p>
        </div>
      )}

      <input
        type="file"
        accept="image/*"
        capture="environment"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
      />
    </div>
  );
};
