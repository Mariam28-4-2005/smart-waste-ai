
import React from 'react';
import { MOCK_RECYCLING_CENTERS } from '../constants';
import type { RecyclingCenter } from '../types';
import { MapPinIcon, ClockIcon } from './Icons';

const CenterCard: React.FC<{ center: RecyclingCenter }> = ({ center }) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow transition-transform hover:scale-105">
      <h3 className="text-lg font-bold text-gray-800">{center.name}</h3>
      <div className="text-sm text-gray-600 mt-2 space-y-1">
        <p className="flex items-center"><MapPinIcon className="h-4 w-4 mr-2 flex-shrink-0" />{center.address}</p>
        <p className="flex items-center"><ClockIcon className="h-4 w-4 mr-2 flex-shrink-0" />{center.hours}</p>
      </div>
      <div className="mt-3">
        <p className="text-xs font-semibold text-gray-500 mb-1">Accepts:</p>
        <div className="flex flex-wrap gap-2">
          {center.accepts.map(item => (
            <span key={item} className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full font-medium">
              {item}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};


export const MapView: React.FC = () => {
  return (
    <div className="p-2 space-y-4 animate-fade-in">
      <h1 className="text-3xl font-bold text-gray-800">Nearby Centers</h1>
      
      <div className="relative h-48 bg-gray-200 rounded-lg overflow-hidden shadow-inner">
        <img src={`https://picsum.photos/seed/map/400/200`} alt="Map placeholder" className="w-full h-full object-cover opacity-70" />
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30">
          <p className="text-white font-semibold text-center p-4">
            Map functionality would be implemented here using a service like Google Maps.
          </p>
        </div>
      </div>
      
      <div className="space-y-4">
        {MOCK_RECYCLING_CENTERS.map((center, index) => (
          <CenterCard key={index} center={center} />
        ))}
      </div>
    </div>
  );
};
