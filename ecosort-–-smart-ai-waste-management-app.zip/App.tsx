
import React, { useState, useMemo } from 'react';
import { Scanner } from './components/Scanner';
import { Stats } from './components/Stats';
import { Rewards } from './components/Rewards';
import { MapView } from './components/MapView';
import { Header } from './components/Header';
import { EcoTip } from './components/EcoTip';
import type { ScanResult, Badge, LeaderboardUser } from './types';
import { WasteCategory } from './types';
import { BADGES, MOCK_LEADERBOARD_DATA } from './constants';
import { RecycleIcon, ChartBarIcon, TrophyIcon, MapPinIcon } from './components/Icons';

type View = 'scanner' | 'stats' | 'rewards' | 'map';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('scanner');
  const [scanHistory, setScanHistory] = useState<ScanResult[]>([]);
  const [ecoPoints, setEcoPoints] = useState<number>(0);

  const handleScanComplete = (result: ScanResult) => {
    setScanHistory(prev => [...prev, result]);
    const points = result.category === WasteCategory.Landfill || result.category === WasteCategory.Hazardous ? 5 : 10;
    setEcoPoints(prev => prev + points);
    setCurrentView('scanner'); // Stay on scanner view to show result
  };
  
  const unlockedBadges = useMemo<Badge[]>(() => {
    return BADGES.filter(badge => ecoPoints >= badge.pointsRequired);
  }, [ecoPoints]);

  const leaderboardData: LeaderboardUser[] = useMemo(() => {
    const userEntry = { name: 'You', points: ecoPoints, isUser: true };
    const sortedData = [...MOCK_LEADERBOARD_DATA, userEntry]
      .sort((a, b) => b.points - a.points)
      .slice(0, 10);
    return sortedData;
  }, [ecoPoints]);


  const renderView = () => {
    switch (currentView) {
      case 'stats':
        return <Stats scanHistory={scanHistory} ecoPoints={ecoPoints} />;
      case 'rewards':
        return <Rewards unlockedBadges={unlockedBadges} leaderboardData={leaderboardData} />;
      case 'map':
        return <MapView />;
      case 'scanner':
      default:
        return <Scanner onScanComplete={handleScanComplete} latestResult={scanHistory.length > 0 ? scanHistory[scanHistory.length - 1] : null} />;
    }
  };

  const navItems = [
    { id: 'scanner', label: 'Scan', icon: <RecycleIcon className="h-6 w-6" /> },
    { id: 'stats', label: 'Stats', icon: <ChartBarIcon className="h-6 w-6" /> },
    { id: 'rewards', label: 'Rewards', icon: <TrophyIcon className="h-6 w-6" /> },
    { id: 'map', label: 'Map', icon: <MapPinIcon className="h-6 w-6" /> },
  ];

  return (
    <div className="min-h-screen bg-gray-100 font-sans flex flex-col items-center">
      <div className="w-full max-w-md bg-white shadow-lg flex flex-col h-screen">
        <Header />
        <main className="flex-grow p-4 md:p-6 overflow-y-auto">
          {renderView()}
        </main>
        <EcoTip />
        <footer className="w-full border-t border-gray-200 bg-white">
          <nav className="flex justify-around items-center h-16">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id as View)}
                className={`flex flex-col items-center justify-center w-1/4 transition-colors duration-200 ${
                  currentView === item.id ? 'text-green-600' : 'text-gray-500 hover:text-green-500'
                }`}
              >
                {item.icon}
                <span className="text-xs font-medium mt-1">{item.label}</span>
              </button>
            ))}
          </nav>
        </footer>
      </div>
    </div>
  );
};

export default App;
