
import type { Badge, LeaderboardUser, RecyclingCenter } from './types';

export const ECO_TIPS: string[] = [
    "Reduce paper usage by opting for digital receipts.",
    "Carry a reusable water bottle to avoid single-use plastics.",
    "Turn off lights when you leave a room to save energy.",
    "Compost food scraps to reduce landfill waste and enrich soil.",
    "Use reusable shopping bags instead of plastic ones.",
    "Fix leaky faucets to conserve water.",
    "Choose products with minimal packaging.",
    "Donate old clothes and items instead of throwing them away.",
    "A single recycled plastic bottle can save enough energy to power a 60-watt bulb for 3 hours."
];

export const BADGES: Badge[] = [
    { name: 'Eco Starter', description: 'Scanned your first item!', icon: 'fas fa-seedling', pointsRequired: 10 },
    { name: 'Recycling Rookie', description: 'Earned 50 eco-points.', icon: 'fas fa-recycle', pointsRequired: 50 },
    { name: 'Green Guardian', description: 'Earned 150 eco-points.', icon: 'fas fa-leaf', pointsRequired: 150 },
    { name: 'Sustainability Steward', description: 'Earned 300 eco-points.', icon: 'fas fa-shield-alt', pointsRequired: 300 },
    { name: 'Planet Protector', description: 'Earned 500 eco-points.', icon: 'fas fa-globe-americas', pointsRequired: 500 },
];

export const MOCK_LEADERBOARD_DATA: LeaderboardUser[] = [
    { name: 'Alex G.', points: 480 },
    { name: 'Brenda H.', points: 455 },
    { name: 'Carlos R.', points: 390 },
    { name: 'Diana P.', points: 310 },
    { name: 'Ethan W.', points: 250 },
    { name: 'Fiona L.', points: 180 },
    { name: 'George K.', points: 120 },
    { name: 'Hannah M.', points: 95 },
];

export const MOCK_RECYCLING_CENTERS: RecyclingCenter[] = [
    {
        name: 'GreenValley Recycling Hub',
        address: '123 Eco Lane, Springfield',
        hours: 'Mon-Sat: 8am - 6pm',
        accepts: ['Plastic', 'Glass', 'Paper', 'Aluminum']
    },
    {
        name: 'City Central Drop-off',
        address: '456 Recycle Ave, Metropolis',
        hours: 'Tue-Sun: 9am - 5pm',
        accepts: ['Electronics', 'Batteries', 'Cardboard']
    },
    {
        name: 'Oakwood Compost Facility',
        address: '789 Garden Way, Oakwood',
        hours: 'Mon-Fri: 7am - 4pm',
        accepts: ['Yard Waste', 'Food Scraps']
    },
];
