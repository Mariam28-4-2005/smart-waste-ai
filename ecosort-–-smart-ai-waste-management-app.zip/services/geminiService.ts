
import { GoogleGenAI, Type } from '@google/genai';
import type { ScanResult } from '../types';
import { WasteCategory } from '../types';

const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
        if (typeof reader.result === 'string') {
            resolve(reader.result.split(',')[1]);
        } else {
            resolve(''); // Should not happen with readAsDataURL
        }
    };
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const classifyWaste = async (imageFile: File): Promise<Omit<ScanResult, 'imageUrl'>> => {
    if (!process.env.API_KEY) {
        console.error("API Key is missing.");
        // Return mock data if API key is not set
        return {
            itemName: 'Plastic Bottle',
            category: WasteCategory.Recycling,
            reason: 'This is a mock response. API key not configured. This item is typically made of PET plastic, which is widely recyclable.'
        };
    }
  
    const imagePart = await fileToGenerativePart(imageFile);
    const prompt = "Analyze this image and identify the item. Classify it into one of the following waste categories: 'Recycling', 'Compost', 'Landfill', 'Hazardous', or 'Special'. Provide a brief, one-sentence explanation for the classification.";

    const schema = {
        type: Type.OBJECT,
        properties: {
            itemName: {
                type: Type.STRING,
                description: 'The name of the identified item (e.g., "plastic bottle", "apple core").'
            },
            category: {
                type: Type.STRING,
                enum: Object.values(WasteCategory),
                description: 'The waste category for the item.'
            },
            reason: {
                type: Type.STRING,
                description: 'A brief explanation for the classification.'
            }
        },
        required: ['itemName', 'category', 'reason']
    };

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, { text: prompt }] },
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
            }
        });

        const jsonResponse = JSON.parse(response.text);

        // Validate the category from the response
        const categoryString = jsonResponse.category;
        const category = Object.values(WasteCategory).includes(categoryString as WasteCategory)
            ? categoryString as WasteCategory
            : WasteCategory.Unknown;

        return {
            itemName: jsonResponse.itemName || 'Unknown Item',
            category: category,
            reason: jsonResponse.reason || 'No reason provided.'
        };
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to classify waste item.");
    }
};
